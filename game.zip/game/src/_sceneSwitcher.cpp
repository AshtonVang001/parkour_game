#include "_sceneSwitcher.h"

_sceneSwitcher::_sceneSwitcher()
{

}

_sceneSwitcher::~_sceneSwitcher()
{

}
