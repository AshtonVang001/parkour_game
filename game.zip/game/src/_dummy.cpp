#include "_dummy.h"

_dummy::_dummy()
{
    //ctor
}

_dummy::~_dummy()
{
    //dtor
}
