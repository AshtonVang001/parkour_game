#ifndef _DUMMY_H
#define _DUMMY_H


class _dummy
{
    public:
        _dummy();
        virtual ~_dummy();

    protected:

    private:
};

#endif // _DUMMY_H
